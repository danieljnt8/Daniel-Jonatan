package fop.model.tile;

/**
 * This class contains the different Feature Type
 *
 */
public enum FeatureType {

	CASTLE, ROAD, MONASTERY, FIELDS,

}
