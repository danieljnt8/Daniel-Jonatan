package fop.model.tile;

/**
 * This "enum" class contains all the different Tile Types and the flipsinde.
 *
 */
public enum TileType {

	A, B, C, D, E, F, G, H, I, J, K, L, M, N, O, P, Q, R, S, T, U, V, W, X, FLIPSIDE;

}
