package fop.model.gameplay;

/**
 * This "enum" class contains the different states JUST for the game
 *
 */
public enum State {
	GAME_START, PLACING_TILE, PLACING_MEEPLE, GAME_OVER

}
